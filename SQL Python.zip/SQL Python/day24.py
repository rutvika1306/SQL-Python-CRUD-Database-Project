# -*- coding: utf-8 -*-
"""
Created on Mon Aug 25 13:28:50 2025

@author: rutvi
"""

import pandas as pd
from pandasql import sqldf
from pandasql import load_births
births=load_births()
print(births)


cmd="SELECT * FROM births where births>300000 limit 10;"
print(sqldf(cmd,locals()))


import sqlite3
conn=sqlite3.connect("C:/Users/rutvi/dataset.bd")
print(conn)