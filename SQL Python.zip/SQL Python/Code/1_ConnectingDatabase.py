import mysql.connector 
db = mysql.connector.connect(host="localhost",user="root",password="1122")
if db:
  print("Connection successful")
else:
  print("Connection Failed")
